<?php
date_default_timezone_set("UTC");
$conn = new mysqli('localhost:3306','myporta7_anmol','aqe~QeFRhc*X','myporta7_new');
?>